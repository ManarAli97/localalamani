<?php  foreach ($result as $data)  {

	echo $data['content'];

   }
?>


