<?php

trait report_serial_entry
{

    protected  $data_code=array();

    function __construct()
    {
        parent::__construct();
        $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS);//databaseObject
    }




    function repet($flag)
    {
        if ($flag==0)
        {
            $this->setting->set('repet',1) ;
        }else
        {
            $this->setting->set('repet',2) ;
        }

    }


    function list_report_serial_entry()
    {

        $this->checkPermit('generation_serial',$this->folder);

        $this->adminHeaderController($this->langControl($this->folder));

        require ($this->render($this->folder,'report_serial_entry/html','list','php'));
        $this->adminFooterController();

    }



    function add_report_serial_entry()
    {

        $this->checkPermit('add_report_serial_entry',  $this->folder);
        $this->adminHeaderController($this->langControl('add_report_serial_entry'));



        require($this->render($this->folder, 'report_serial_entry/html', 'add', 'php'));
        $this->adminFooterController();

    }





    function from_add()
    {


        $this->checkPermit('add_report_serial_entry',  $this->folder);


        if (isset($_POST['submit'])) {

            try {

                $form = new  Form();
                $form->post('bill')
                    ->val('is_empty', $this->langControl('required'))
                    ->val('strip_tags');

                $form->post('code')
                    ->val('is_empty', $this->langControl('required'))
                    ->val('strip_tags');

                $form->post('serial')
                    ->val('is_array', $this->langControl('required'))
                    ->val('strip_tags');

                $form->post('type_enter')
                    ->val('is_array', $this->langControl('required'))
                    ->val('strip_tags');

                $form->post('new_page')
                    ->val('is_empty', $this->langControl('required'))
                    ->val('strip_tags');

                $form->post('time_taken')
                    ->val('strip_tags');


                $form->submit();
                $data = $form->fetch();


                $serial = json_decode($data['serial'], true);
                $type_enter = json_decode($data['type_enter'], true);

                $data['userid'] = $this->userid;
                $data['date'] = time();
                $data['model'] = $this->model_code(trim($data['code']));

                $time_taken=$this->time_reg($data['time_taken']);


                if ($data['new_page'] == 1) {

                    $stmtpage = $this->db->prepare("SELECT `page` FROM serial    ORDER BY page DESC LIMIT 1");
                    $stmtpage->execute();
                    if ($stmtpage->rowCount() > 0) {
                        $page = $stmtpage->fetch(PDO::FETCH_ASSOC)['page'] + 1;
                        $_SESSION['page_serial'] = $page;
                    } else {
                        $stmt2 = $this->db->prepare("SELECT `page` FROM serial   ORDER BY page DESC LIMIT 1");
                        $stmt2->execute();
                        $page = $stmt2->fetch(PDO::FETCH_ASSOC)['page'] + 1;
                        $_SESSION['page_serial'] = $page;
                    }

                } else
                {
                    $page = $_SESSION['page_serial'] ;
                }

                foreach ($serial  as $key=> $sel)
                {

                    if ($sel) {

                        if ($type_enter[$key]) {
                            $type_etr = $type_enter[$key];
                        } else {
                            $type_etr = 'ادخال يدوي';
                        }


                        $sel = trim($sel);


                        if ($this->setting->get('repet') == 2)
                        {
                            $stmt = $this->db->prepare("INSERT INTO `serial` ( page,bill, code, serial, type_enter, quantity, userId, date, model,time_taken) VALUE (?,?,?,?,?,?,?,?,?,?) ");
                            $stmt->execute(array($page, trim($data['bill']), trim($data['code']), $sel, $type_etr, 1, $this->userid, time(), $data['model'],$time_taken));
                            $this->deleteCodeFromSerialConform(trim($data['code']),$data['model']);

                        }
                        else
                        {

                            $stmt = $this->db->prepare("SELECT * FROM serial WHERE code =? AND  serial=? AND  model=? AND bill =? ");
                            $stmt->execute(array(trim($data['code']), $sel, $data['model'], trim($data['bill'])));
                            if ($stmt->rowCount() <= 0) {
                                $stmt = $this->db->prepare("INSERT INTO `serial` ( page,bill, code, serial, type_enter, quantity, userId, date, model,time_taken) VALUE (?,?,?,?,?,?,?,?,?,?) ");
                                $stmt->execute(array($page, trim($data['bill']), trim($data['code']), $sel, $type_etr, 1, $this->userid, time(), $data['model'],$time_taken));
                                $this->deleteCodeFromSerialConform(trim($data['code']),$data['model']);

                            }


                        }

                    }
                }
            echo 'true';


            } catch (Exception $e) {

                $data = $form->fetch();
                $this->error_form = $e->getMessage();
            }

        }

    }


    function time_reg($time)
    {

        if ($time <= 59)
        {
            return    $time . '  ثانية ';
        }else {


            $H = floor($time / 3600);

            if ($H >= 1 )
            {
                return   $H . '  ساعة ' ;
            }else
            {
                $i = ($time / 60) % 60;
                return    $i . '  دقيقة ' ;
            }
        }

    }







    function insert_data()
    {


            $date_now_js = $_GET['date_now'];
            $time = date('s', time());
            $t = $time - $date_now_js;

            if ($t <= 0.1) {
                echo 'جهاز قارئ الباركود';

            } else {

                echo 'ادخال يدوي';
            }

        }




    public function processing_report_serial_entry()
    {


        $table = $this->serial;
        $primaryKey = $table.'.id';

        $columns = array(

            array( 'db' => $table.'.page', 'dt' => 0,
                'formatter' => function ($d, $row) {
                    return "<a href='".url.'/'.$this->folder."/details_page/{$d}'>{$d}</a>";
                }
            ),
            array( 'db' => $table.'.bill', 'dt' => 1 ),
            array( 'db' => 'user.username', 'dt' => 2 ),

            array( 'db' =>  $table.'.date', 'dt' => 3 ,
                'formatter' => function ($id, $row) {
                    return date('Y-m-d h:i:s a',$id);
                }
            ),

            array(  'db' =>   $table.'.id', 'dt'=> 4)


        );

        $sql_details = array(
            'user' => DB_USER,
            'pass' => DB_PASS,
            'db'   => DB_NAME,
            'host' => DB_HOST,
            'charset' => 'utf8'
        );

        $join = " inner JOIN user ON user.id = {$table}.userid   ";
        $whereAll = array("");
        $group = "GROUP BY page";


        echo json_encode(

            SSP::complex_join($_GET, $sql_details, $table, $primaryKey, $columns, $join, null, $whereAll,null,$group,1));

    }


    function model_code($code)
    {


        $code=trim($code);

        $stmt=$this->db->prepare("SELECT  code FROM code where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'mobile';
        }

        $stmt=$this->db->prepare("SELECT  code FROM color_accessories where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'accessories';
        }

        $stmt=$this->db->prepare("SELECT  code FROM code_camera where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'camera';
        }

        $stmt=$this->db->prepare("SELECT  code FROM code_games where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'games';
        }

        $stmt=$this->db->prepare("SELECT  code FROM code_network where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'network';
        }

        $stmt=$this->db->prepare("SELECT  code FROM product_savers where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'savers';
        }

        $stmt=$this->db->prepare("SELECT  code FROM code_computer where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'computer';
        }

        $stmt=$this->db->prepare("SELECT  code FROM code_printing_supplies where code = ?");
        $stmt->execute(array($code));
        if ($stmt->rowCount()>0)
        {
            return 'printing_supplies';
        }

        return '';

    }






    function details_page($id)
    {

        $this->checkPermit('details_page',$this->folder);
        $this->adminHeaderController($this->langControl($this->folder));



        require ($this->render($this->folder,'report_serial_entry/html','details_page','php'));
        $this->adminFooterController();

    }


    public function processing_details_page($id)
    {


        $table = $this->serial;
        $primaryKey = $table.'.id';

        $columns = array(

            array( 'db' => $table.'.bill', 'dt' => 0),
            array( 'db' => $table.'.code', 'dt' => 1),
            array( 'db' => $table.'.serial', 'dt' => 2 ),
            array( 'db' => $table.'.type_enter', 'dt' => 3 ),
            array( 'db' => 'user.username', 'dt' => 4 ),

            array( 'db' =>  $table.'.date', 'dt' => 5 ,
                'formatter' => function ($id, $row) {
                    return date('Y-m-d h:i:s a',$id);
                }
            ),

            array(  'db' =>   $table.'.id', 'dt'=> 6)


        );

        $sql_details = array(
            'user' => DB_USER,
            'pass' => DB_PASS,
            'db'   => DB_NAME,
            'host' => DB_HOST,
            'charset' => 'utf8'
        );

        $join = " inner JOIN user ON user.id = {$table}.userid   ";
        $whereAll = array("page={$id}");


        echo json_encode(

            SSP::complex_join($_GET, $sql_details, $table, $primaryKey, $columns, $join, null, $whereAll,null,null,1));

    }




    function  list_material()
    {

        $this->checkPermit('details_page',$this->folder);
        $this->adminHeaderController($this->langControl($this->folder));



        require ($this->render($this->folder,'report_serial_entry/html','material','php'));
        $this->adminFooterController();

    }


    public function processing_material()
    {


        $table = $this->serial;
        $primaryKey = $table.'.id';

        $columns = array(

            array( 'db' => $table.'.model', 'dt' => 0 ,
                'formatter' => function ($id, $row) {
                    return  $id."[". $this->langControl($id) ."]";
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 1 ,
                'formatter' => function ($id, $row) {
                 $this->data_code=$this->data_code($id,$row[0]);
                    return  $this->data_code['title'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 2),
            array( 'db' => $table.'.code', 'dt' => 3 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['color'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 4 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['size'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 5,
                'formatter' => function ($id, $row) {

                $m="'{$row[0]}'";
                return '
                <button class="btn btn-primary" onclick="get_serial('.$id.','.$m.')"  type="button" data-toggle="collapse" data-target="#multiCollapseExample-'.$id.$row[0].'" aria-expanded="false" aria-controls="multiCollapseExample'.$id.$row[0].'">'.$this->sum_serial_enter($id,$row[0]).'</button>
                   <div class="collapse multi-collapse" id="multiCollapseExample-'.$id.$row[0].'">
                      <div style="padding: 5px;margin:0" class="card card-body" id="data_collapse_'.$id.$row[0].'">
                   </div>
                </div>
                ';
                }
                ),


            array( 'db' => $table.'.code', 'dt' => 6 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['quantity'];
                }
            ),

            array( 'db' => $table.'.code', 'dt' => 7 ,
                'formatter' => function ($id, $row) {
                    return   $this->time_taken($id,$row[0])   ;
                }
            ),

            array( 'db' =>  $table.'.date', 'dt' => 8 ,
                'formatter' => function ($id, $row) {
                    return date('Y-m-d h:i:s a',$id);
                }
            ),

            array( 'db' =>  $table.'.code', 'dt' => 9 ,
                'formatter' => function ($id, $row) {
                    if ($this->permit('delete_serial',$this->folder))
                    {
                        $code="'{$id}'";
                        $model="'{$row[0]}'";
                        return '
                          <button class="btn btn-primary" onclick="get_serial_by_code('.$code.','.$model.')"  type="button"  ><i class="fa fa-trash"></i> </button>   
                    ';
                    }
                }
            ),

            array(  'db' =>   $table.'.id', 'dt'=> 10),




        );

        $sql_details = array(
            'user' => DB_USER,
            'pass' => DB_PASS,
            'db'   => DB_NAME,
            'host' => DB_HOST,
            'charset' => 'utf8'
        );

        $join = " inner JOIN user ON user.id = {$table}.userid   ";
        $whereAll = array("");
        $group="  GROUP BY {$table}.code  ";

        echo json_encode(

            SSP::complex_join($_GET, $sql_details, $table, $primaryKey, $columns, $join, null, $whereAll,null,$group,1));

    }



function delete_serial($id)
{
    if ($this->handleLogin())
    {

        $stmtRow = $this->db->prepare("SELECT * FROM serial WHERE id=? ");
        $stmtRow ->execute(array($id));
        $result=$stmtRow->fetch(PDO::FETCH_ASSOC);
        $time=time();
        $stmtData  = $this->db->prepare("INSERT INTO serial_delete (page, bill, code, serial, type_enter, quantity, model, userId, date)  SELECT page, bill, code, serial, type_enter, quantity, model, $this->userid, $time  FROM serial WHERE id=?");
        $stmtData ->execute(array($id));

        $stmt  = $this->db->prepare("DELETE FROM serial WHERE id=?");
        $stmt ->execute(array($id));
        $this->insertCodeSerial_conform($result['code'],$result['mode'],'حذف سيريال');
        echo 'true';
    }

}

function get_serial_by_code($code,$model)
{
    if ($this->handleLogin())
    {

        $time=time();
        if ($this->admin($this->userid))
        {
            $stmtRow = $this->db->prepare("SELECT * FROM serial WHERE code=? AND model=?");
            $stmtRow ->execute(array($code,$model));
        }else
        {
            $stmtRow = $this->db->prepare("SELECT * FROM serial WHERE code=? AND model=? AND  userId=?");
            $stmtRow ->execute(array($code,$model,$this->userid));
        }

        while ($row = $stmtRow->fetch(PDO::FETCH_ASSOC) )
        {
            $stmtData  = $this->db->prepare("INSERT INTO serial_delete (page, bill, code, serial, type_enter, quantity, model, userId, date)  SELECT page, bill, code, serial, type_enter, quantity, model, $this->userid, $time  FROM serial WHERE id=?");
            $stmtData ->execute(array($row['id']));
            $this->insertCodeSerial_conform($row['code'],$row['mode'],'حذف سيريال');

        }
        if ($this->admin($this->userid))
        {
            $stmt  = $this->db->prepare("DELETE FROM serial WHERE code=? AND model=?");
            $stmt ->execute(array($code,$model));

        }else
        {
            $stmt  = $this->db->prepare("DELETE FROM serial WHERE code=? AND model=? AND userId=?");
            $stmt ->execute(array($code,$model,$this->userid));


        }
        echo 'true';
    }

}


function get_serial($code,$model)
{

    if ($this->admin($this->userid)) {
        $stmt  = $this->db->prepare("SELECT   id,serial  FROM serial  WHERE code=? AND  model=?  ");
        $stmt ->execute(array($code,$model));
    }else
    {
        $stmt  = $this->db->prepare("SELECT   id,serial  FROM serial  WHERE code=? AND  model=? AND  userId =?  ");
        $stmt ->execute(array($code,$model,$this->userid));
    }

    $html = '';
  if ($stmt->rowCount() > 0) {

      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       if ($this->permit('delete_serial',$this->folder))
       {
           $html .= "<div class='list_serial' id='serial_{$row['id']}'>  {$row['serial']}  <span onclick='delete_serial({$row['id']})'><i class='fa fa-times-circle'></i> </span> </div>";
       }
      }
  }else
  {
      $html .= "<div class='list_serial'>لا يوجد سيريال</div>";
  }
   echo $html;
}

function data_code($code,$model)
{

    if ($model=='accessories')
    {
        $stmt=$this->db->prepare("SELECT  accessories.title,excel_accessories.quantity,color_accessories.color FROM color_accessories INNER JOIN  accessories ON  accessories.id=color_accessories.id_item left JOIN  excel_accessories ON excel_accessories.code=color_accessories.code WHERE color_accessories.code=? LIMIT  1");
        $stmt->execute(array($code));
        $result=$stmt->fetch(PDO::FETCH_ASSOC);
        $result['size']='';

    }else if($model=='savers')
    {

        $stmt=$this->db->prepare("SELECT  product_savers.title,excel_savers.quantity,product_savers.color FROM product_savers    left JOIN  excel_savers ON excel_savers.code=product_savers.code WHERE product_savers.code=? LIMIT  1");
        $stmt->execute(array($code));
        $result=$stmt->fetch(PDO::FETCH_ASSOC);
        $result['size']='';

    }else
    {

        if ($model == 'mobile')
        {

            $code_table='code';
            $color='color';
            $excel='excel';
        }else
        {
            $code_table='code_'.$model;
            $color='color_'.$model;
            $excel='excel_'.$model;
        }

        $stmt=$this->db->prepare("SELECT  {$model}.title,{$color}.color,{$code_table}.size,{$excel}.quantity FROM {$code_table} INNER JOIN  {$color} ON  {$color}.id={$code_table}.id_color INNER JOIN  {$model} ON {$model}.id={$color}.id_item left JOIN  {$excel} ON {$excel}.code={$code_table}.code   WHERE {$code_table}.code=? LIMIT  1");
        $stmt->execute(array($code));
        $result=$stmt->fetch(PDO::FETCH_ASSOC);
    }


   return $result;


}

    function list_serial_deleted()
    {

        $this->checkPermit('list_serial_deleted',$this->folder);
        $this->adminHeaderController($this->langControl($this->folder));



        require ($this->render($this->folder,'report_serial_entry/html','serial_deleted','php'));
        $this->adminFooterController();

    }


    public function processing_serial_deleted()
    {


        $table = $this->serial_delete;
        $primaryKey = $table.'.id';

        $columns = array(

            array( 'db' => $table.'.bill', 'dt' => 0),
            array( 'db' => $table.'.code', 'dt' => 1),
            array( 'db' => $table.'.serial', 'dt' => 2 ),
            array( 'db' => $table.'.type_enter', 'dt' => 3 ),
            array( 'db' => 'user.username', 'dt' => 4 ),

            array( 'db' =>  $table.'.date', 'dt' => 5 ,
                'formatter' => function ($id, $row) {
                    return date('Y-m-d h:i:s a',$id);
                }
            ),

            array(  'db' =>   $table.'.id', 'dt'=> 6)


        );

        $sql_details = array(
            'user' => DB_USER,
            'pass' => DB_PASS,
            'db'   => DB_NAME,
            'host' => DB_HOST,
            'charset' => 'utf8'
        );

        $join = " inner JOIN user ON user.id = {$table}.userid   ";
        $whereAll = array("");


        echo json_encode(

            SSP::complex_join($_GET, $sql_details, $table, $primaryKey, $columns, $join, null, $whereAll,null,null,1));

    }





}