<?php

trait serial_material_inventory
{

    protected  $data_code=array();

    function __construct()
    {
        parent::__construct();
        $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS);//databaseObject
    }



    function  serial_material_inventory()
    {

        $this->checkPermit('serial_material_inventory',$this->folder);
        $this->adminHeaderController($this->langControl($this->folder));



        require ($this->render($this->folder,'serial_material_inventory/html','material','php'));
        $this->adminFooterController();

    }


    public function processing_serial_material_inventory()
    {


        $table = $this->serial;
        $primaryKey = $table.'.id';

        $columns = array(

            array( 'db' => $table.'.model', 'dt' => 0 ,
                'formatter' => function ($id, $row) {
                    return  $id."[". $this->langControl($id) ."]";
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 1 ,
                'formatter' => function ($id, $row) {
                 $this->data_code=$this->data_code($id,$row[0]);
                    return  $this->data_code['title'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 2),
            array( 'db' => $table.'.code', 'dt' => 3 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['color'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 4 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['size'];
                }
            ),
            array( 'db' => $table.'.code', 'dt' => 5,
                'formatter' => function ($id, $row) {

                $m="'{$row[0]}'";
                return '
                <button class="btn btn-primary" onclick="get_serial('.$id.','.$m.')"  type="button" data-toggle="collapse" data-target="#multiCollapseExample-'.$id.$row[0].'" aria-expanded="false" aria-controls="multiCollapseExample'.$id.$row[0].'">'.$this->sum_serial_enter($id,$row[0]).'</button>
                   <div class="collapse multi-collapse" id="multiCollapseExample-'.$id.$row[0].'">
                      <div style="padding: 5px;margin:0" class="card card-body" id="data_collapse_'.$id.$row[0].'">
                   </div>
                </div>
                ';
                }
                ),


            array( 'db' => $table.'.code', 'dt' => 6 ,
                'formatter' => function ($id, $row) {
                    return  $this->data_code['quantity'];
                }
            ),

            array( 'db' => $table.'.code', 'dt' => 7 ,
                'formatter' => function ($id, $row) {
                    return   $this->time_taken($id,$row[0])   ;
                }
            ),

            array( 'db' =>  $table.'.date', 'dt' => 8 ,
                'formatter' => function ($id, $row) {
                    return date('Y-m-d h:i:s a',$id);
                }
            ),

            array( 'db' =>  $table.'.code', 'dt' => 9 ,
                'formatter' => function ($id, $row) {
                    if ($this->permit('delete_serial',$this->folder))
                    {
                        $code="'{$id}'";
                        $model="'{$row[0]}'";
                        return '
                          <button class="btn btn-primary" onclick="get_serial_by_code('.$code.','.$model.')"  type="button"  ><i class="fa fa-trash"></i> </button>   
                    ';
                    }
                }
            ),

            array(  'db' =>   $table.'.id', 'dt'=> 10),




        );

        $sql_details = array(
            'user' => DB_USER,
            'pass' => DB_PASS,
            'db'   => DB_NAME,
            'host' => DB_HOST,
            'charset' => 'utf8'
        );

        $join = " inner JOIN user ON user.id = {$table}.userid   ";

       if ($this->admin($this->userid))
       {
           $whereAll = array("");
       }else
       {
           $whereAll = array("userId={$this->userid}");
       }

        $group="  GROUP BY {$table}.code  ";

        echo json_encode(

            SSP::complex_join($_GET, $sql_details, $table, $primaryKey, $columns, $join, null, $whereAll,null,$group,1));

    }



    function time_taken($code,$model)
    {

        if ($this->admin($this->userid))
        {
            $stmt  = $this->db->prepare("SELECT  time_taken  FROM serial  WHERE code=? AND  model=? ORDER BY  id DESC LIMIT 1");
            $stmt ->execute(array($code,$model));
        }else
        {
            $stmt  = $this->db->prepare("SELECT  time_taken  FROM serial  WHERE code=? AND  model=? AND userId =? ORDER BY  id DESC LIMIT 1");
            $stmt ->execute(array($code,$model,$this->userid));
        }

        return $stmt ->fetch(PDO::FETCH_ASSOC)['time_taken'] ;
    }


    function sum_serial_enter($code,$model)
    {


        if ($this->admin($this->userid))
        {
            $stmt  = $this->db->prepare("SELECT  SUM(quantity) as q FROM serial  WHERE code=? AND  model=?  ");
            $stmt ->execute(array($code,$model));
        }else
        {
            $stmt  = $this->db->prepare("SELECT  SUM(quantity) as q FROM serial  WHERE code=? AND  model=? AND userId = ?");
            $stmt ->execute(array($code,$model,$this->userid));
        }
        return $stmt ->fetch(PDO::FETCH_ASSOC)['q'] ;
    }





}