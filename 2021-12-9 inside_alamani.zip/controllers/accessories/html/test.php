 <?php  $this->publicHeader( 'test');  ?>

   <br>
   <br>   <br>
   <br>
   <br>
   <br>   <br>

<?php $this->publicFooter(); ?>