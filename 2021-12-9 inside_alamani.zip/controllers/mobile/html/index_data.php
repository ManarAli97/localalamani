
<div class="tab-content contentTabPhoneModel" id="myTabContent">
    <?php foreach ($category_mobile as $key => $cat_tab) {   ?>

        <div class="tab-pane  <?php if ($key==0) echo 'show active' ?>  " id="mobileCat_<?php echo $id ?>" role="tabpanel" aria-labelledby="mobile-tab_<?php echo  $id ?>">

            <div class="phoneModel">

                <div class="control_slider">
                    <div class="row">
                        <div class="col-auto border" style="width: 50px">
                            <a class="carousel-control-prev row_prev" href="#carouselExampleControlsPhone-<?php echo  $id ?>" role="button" data-slide="prev">
                                <i class="fa fa-chevron-left"></i>
                            </a>
                            <a class="carousel-control-next row_next" href="#carouselExampleControlsPhone-<?php echo  $id  ?>" role="button" data-slide="next">
                                <i class="fa fa-chevron-right"></i>
                            </a>

                        </div>

                        <div class="col-auto  titleCatLg">
                            موبايلات
                        </div>
                    </div>
                </div>

                <div id="carouselExampleControlsPhone-<?php echo $id ?>" class="carousel slide" data-ride="carousel" >
                    <div class="carousel-inner" role="listbox">

                        <?php  foreach ($cat_tab['content'] as $index=> $content) { ?>
                            <div class="carousel-item  <?php if ($index==0) echo 'active' ?>  ">
                                <div class="row">

                                    <?php  foreach ($content as $printContent)  { ?>

                                        <div class="col-lg-3 col-md-4 col-sm-6 col-6 xBoxG">

                                            <div  class="infoDevice">


                                                <?php  if ($printContent['bast_it'] == 1 ) { ?>
                                                    <div class="bast_device">
                                                        <?php echo $this->langSite('bast_it') ?>
                                                    </div>

                                                <?php } ?>

                                                <?php  if ($printContent['stop'] ==1 ) { ?>
                                                <div class="stop_device">
                                                    <?php echo $this->langSite('stop_product') ?>
                                                </div>
                                                <a href="<?php echo url ?>/mobile/stop/<?php echo $printContent['id'] ?>/<?php echo $printContent['code'] ?>"  >
                                                    <?php  } else if ($printContent['q'] ==0 ) { ?>
                                                    <div class="stop_device">
                                                        <?php echo $this->langSite('out_of_quantity') ?>
                                                    </div>
                                                    <a href="<?php echo url ?>/mobile/stop/<?php echo $printContent['id'] ?>/<?php echo $printContent['code'] ?>"  >
                                                        <?php  }else{   ?>
                                                        <a href="<?php echo url ?>/mobile/details/<?php echo $printContent['id'] ?>"  >
                                                            <?php  }  ?>
                                                            <div class="hoverBtn">
                                                                <button class="btn"><i class="fa fa-search"></i> </button>
                                                            </div>
                                                            <div class="imageDevise">
                                                                <img   src="<?php echo $printContent['image'] ?>" alt="لا توجد صورة">

                                                                <?php  if ($printContent['cuts'] == 1 ) { ?>
                                                                    <div class="price_cuts_note">
                                                                        <?php echo $this->langSite('price_cuts') ?>
                                                                    </div>

                                                                <?php } ?>
                                                            </div>
                                                        </a>

                                                        <div class="nameDevice">
                                                            <?php echo $printContent['title'] ?>

                                                        </div>
                                                        <textarea  disabled class="form-control description"><?php echo $printContent['description'] ?></textarea>
                                                        <div class="row justify-content-center   align-items-center">
                                                            <div class="col-auto">
                                                                <?php  if ($printContent['cuts'] == 1 ) { ?>
                                                                    <div class="pricDevice" style="display: block">
                                                                        <!--                                            <div class="oldXPrice" style="text-decoration: line-through;">--><?php //echo $printContent['price'] ?><!-- </div>-->
                                                                        <div class="price_cuts" style="color: green;font-weight: bold"> <?php echo $printContent['price_cuts'] ?> د.ع   </div>
                                                                    </div>
                                                                <?php  } else{ ?>
                                                                    <div class="pricDevice" >
                                                                        <?php echo $printContent['price'] ?>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="col-auto">
                                                                <button data-toggle="tooltip" data-placement="top" title="عرض سعر الدولار" onclick="get_dollar_price(this,'<?php echo $printContent['priceC'] ?>')" class="btn icon_price_dollar"> <i class="fa fa-usd"></i> </button>
                                                            </div>
                                                        </div>



                                                        <div class="c_device">
                                                            <div class="addedToCart_mobile<?php echo $printContent['id'] ?>"></div>

                                                            <div class="row align-items-center justify-content-center">


                                                                <?php  if ($printContent['stop'] ==1 ||  $printContent['q'] == 0 ) { ?>
                                                                    <div class="col-lg-10 col-md-12 col-sm-12  xcartp"  >

                                                                        <?php if (isset($_SESSION['username_member_r']) || $this->isDirect()) { ?>


                                                                            <?php if ($this->phone=='true' || $this->isDirect()) {   ?>

                                                                                <a href="<?php echo url ?>/mobile/stop/<?php echo $printContent['id'] ?>/<?php echo $printContent['code'] ?>" type="button" class="btn btn_cart"  >
                                                                                    <span>  عرض الاجهزة المشابهه  </span>
                                                                                </a>
                                                                            <?php  }else{   ?>

                                                                                <button type="button" class="btn btn_cart"    data-toggle="modal" data-target="#add_phone">
                                                                                    <span>اضف الى السلة </span> <i class="fa fa-cart-plus"></i>
                                                                                </button>

                                                                            <?php  }  ?>
                                                                        <?php } else { ?>

                                                                            <button type="button" class="btn btn_cart"    data-toggle="modal" data-target="#login_site">
                                                                                <span>اضف الى السلة </span> <i class="fa fa-cart-plus"></i>
                                                                            </button>

                                                                        <?php } ?>


                                                                    </div>

                                                                <?php  } else {  ?>

                                                                    <div class="col-lg-7 col-md-7 col-sm-12  xcartp"  >

                                                                        <?php if (isset($_SESSION['username_member_r']) || $this->isDirect()) { ?>


                                                                            <?php if ($this->phone=='true' || $this->isDirect()) {   ?>

                                                                                <button type="button" class="btn btn_cart" onclick="addToCart(<?php echo $printContent['id'] ?>,'<?php echo $printContent['size'] ?>','<?php echo $printContent['priceC'] ?>','<?php echo $printContent['nameImage'] ?>','<?php echo $printContent['code_color'] ?>','<?php echo $printContent['code'] ?>')">
                                                                                    <span>اضف الى السلة </span> <i class="fa fa-cart-plus"></i>
                                                                                </button>
                                                                            <?php  }else{   ?>

                                                                                <button type="button" class="btn btn_cart"    data-toggle="modal" data-target="#add_phone">
                                                                                    <span>اضف الى السلة </span> <i class="fa fa-cart-plus"></i>
                                                                                </button>

                                                                            <?php  }  ?>
                                                                        <?php } else { ?>

                                                                            <button type="button" class="btn btn_cart"    data-toggle="modal" data-target="#login_site">
                                                                                <span>اضف الى السلة </span> <i class="fa fa-cart-plus"></i>
                                                                            </button>

                                                                        <?php } ?>


                                                                    </div>
                                                                    <div class="col-lg-5 col-md-5 col-sm-12">
                                                                        <?php if (isset($_SESSION['username_member_r'])) { ?>

                                                                            <button   type="button" class="btn btn_like  style_btn_like_mb  L_<?php echo $printContent['id']  ?> <?php  if ($printContent['like']) echo 'unlike'; else echo  'like' ?>"  onclick=<?php  if ($printContent['like']) echo "unlike_d(".$printContent['id'].",'mobile')"; else echo "like_d(".$printContent['id'].",'mobile')" ?>   >
                                                                                <i class="fa fa-heart"></i>
                                                                            </button>

                                                                            <button  title="اضافة المنتج الى خانة المقارنة بين المنتجات"  type="button" class="btn comparison comp_<?php echo $printContent['id']  ?> <?php  if ($printContent['comparison']) echo 'un_comparison'; else echo  'comparison' ?>"  onclick=<?php  if ($printContent['comparison']) echo "un_comparison_d(".$printContent['id'].",'mobile')"; else echo "comparison_d(".$printContent['id'].",'mobile')" ?>   >
                                                                                <i class="fa fa-exchange"></i>
                                                                            </button>
                                                                        <?php } else { ?>

                                                                            <button type="button" class="btn btn_like  style_btn_like_mb "   data-toggle="modal" data-target="#login_site">
                                                                                <i class="fa fa-heart"></i>
                                                                            </button>
                                                                            <button  type="button" class="btn comparison"   data-toggle="modal" data-target="#login_site">
                                                                                <i class="fa fa-exchange"></i>
                                                                            </button>
                                                                        <?php } ?>

                                                                    </div>

                                                                <?php   } ?>

                                                            </div>

                                                        </div>

                                            </div>

                                        </div>
                                    <?php   } ?>
                                </div>
                            </div>

                        <?php   } ?>


                    </div>

                </div>
            </div>

        </div>
    <?php  } ?>

</div>
