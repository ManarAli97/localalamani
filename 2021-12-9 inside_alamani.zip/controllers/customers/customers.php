<?php

class customers extends Controller
{

    function __construct()
    {
        parent::__construct();
        $this->table = 'register_user';
        $this->cart_shop = 'cart_shop';
        $this->register_answer = 'register_answer';
        $this->menu = new Menu();

    }



    public function createTB()
    {

        $this->db->query("CREATE TABLE IF NOT EXISTS `{$this->table}` (
          `id` int(11)  NOT NULL AUTO_INCREMENT ,
          `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `first_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `second_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `third_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `phone` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `country` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `city` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `type_customer` varchar(250)   COLLATE utf8_unicode_ci NOT NULL,
          `type_customer_12` int(11)   COLLATE utf8_unicode_ci NOT NULL,
          `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `uid` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `login` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `ip` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `year` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `birthday` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `date` bigint(20) NOT NULL,
          `date_req` bigint(20) NOT NULL,
          `delivery_service` int(20) NOT NULL,
          `delivery_user` int(20) NOT NULL,
          `last_chat` bigint(20) NOT NULL,
          `wholesale_price` int(20) NOT NULL,
          `active_wholesale_price` int(20) NOT NULL,
          `xc` int(20) NOT NULL DEFAULT 1,
           PRIMARY KEY (`id`)
     ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");

        $this->db->query("CREATE TABLE IF NOT EXISTS `{$this->register_answer}` (
          `id` int(11)  NOT NULL AUTO_INCREMENT ,
          `id_user` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `phone` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
          `note` longtext COLLATE utf8_unicode_ci NOT NULL,
          `choose` longtext COLLATE utf8_unicode_ci NOT NULL,
           `userid` int(20) NOT NULL,
           `date` bigint(20) NOT NULL,

           PRIMARY KEY (`id`)
     ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");

        return $this->db->cht(array($this->table,$this->register_answer));

    }


    public function form()
    {



        $q=array(
            1=>'1. انك ستحصل على انسب سعر و افضل ضمان.',
            2=>'2. ستحصل على انسب سعر و افضل ضمان و الجودة تعني انك اشتريت جهاز لماركة مشهورة.',
            3=>'3. ستحصل على انسب سعر و افضل ضمان لجهاز غير مغشوش "اصلي" في زمن انتشر به الغش بشكل كبير جدا و خصوصا في عالم اجهزة الموبايل لان طرق الغش سهلة و مربحة جداً و تحتاج فقط لشخص غير ملتزم دينيا ليعمل بها و يكسب منها الاموال الحرام الطائلة و من تلك الطرق البسيطة هي استبدال ملحقات الاجهزة الاصلية بملحقات تجارية مشابهة للاصلية و اعادة اقفال كارتونة الجهاز بلاصق او نايلون يشابه لاصق و نايلون الجهاز الاصلي فيصبح فقط صاحب الاختصاص الذي لديه خبرة كافية يستطيع ان يميز الجهاز '
        );

        if (true) {
            try {
                $form = new  Form();

                $form->post('first_name')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');


                $form->post('day')
                    ->val('strip_tags');

                $form->post('month')
                    ->val('strip_tags');

                $form->post('year')
                    ->val('strip_tags');

                $form->post('title')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');

                $form->post('phone')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');

                $form->post('city')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');

                $form->post('address')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');

                $form->post('about_company')
                    ->val('is_empty', 'مطلوب')
                    ->val('strip_tags');

                $form->post('forAnswerThat')
                    ->val('strip_tags');

                $form->post('after_video')
                    ->val('strip_tags');

                $form->post('note')
                    ->val('strip_tags');


                $form->submit();
                $data = $form->fetch();

                $data['year']=date('Y',time());
                $data['date']=time();
                $data['login']='website';
                $data['country']='العراق';
                $data['username']=$data['phone'];
                $data['name'] = $data['first_name'] ;
                $data['uid'] = $this->c_uid(6);
                $data['birthday'] = $data['year'].'-'.$data['month'].'-'.$data['day'];

                $answer=array();

                if ($data['about_company'] == 1  && $data['forAnswerThat'] == 3 )
                {
                    $data['type_customer']='مقتنع';
                    $data['type_customer_12']=1;
                    $answer['choose']=$q[3];
                }

                if ($data['about_company'] == 1  && ($data['forAnswerThat'] == 1 ||  $data['forAnswerThat'] == 2 ))
                {
                    $data['type_customer']='غير مقتنع';
                    $data['type_customer_12']=2;

                    if ( $data['forAnswerThat'] == 1)
                    {
                        $answer['choose']=$q[1];
                    }else if ($data['forAnswerThat'] == 2)
                    {
                        $answer['choose']=$q[2];
                    }else
                    {
                        $answer['choose']=$q[3];
                    }

                }

                if ($data['about_company'] == 2 )
                {
                    if ($data['after_video']==1)
                    {
                        $data['type_customer']='مقتنع';
                        $data['type_customer_12']=1;
                    }
                    else
                    {

                        $data['type_customer']='غير مقتنع';
                        $data['type_customer_12']=2;
                        $answer['note']=$data['note'];
                    }

                }

                if ($data['about_company'] == 1  && ($data['forAnswerThat'] == 1 ||  $data['forAnswerThat'] == 2 ) )
                {
                    if ($data['after_video']==1)
                    {
                        $data['type_customer']='مقتنع';
                        $data['type_customer_12']=1;
                    }
                    else
                    {

                        $data['type_customer']='غير مقتنع';
                        $data['type_customer_12']=2;
                        $answer['note']=$data['note'];
                    }

                }


                if (empty($this->error_form))
                {
                    $stmt2=$this->db->prepare("SELECT *FROM `register_user` WHERE `phone`=?  ");
                    $stmt2->execute(array($data['phone']));
                    if ($stmt2->rowCount()>0)
                    {

						$data['xc']=1;
                        $result=  $stmt2->fetch(PDO::FETCH_ASSOC);

 						$stmt = $this->db->update($this->table, array_diff_key($data,['about_company'=>"delete",'forAnswerThat'=>"delete",'after_video'=>"delete",'note'=>"delete",'day'=>"delete",'month'=>"delete",'year'=>"delete"]),"id={$result['id']}");

                        $_SESSION['username_member_r'] = $data['phone'];
                        $_SESSION['id_member_r'] =$result['id'] ;
                        $_SESSION['name_r'] = $data['name'];
                        $_SESSION['typeLogin'] = $data['login'];

                        $answer['phone'] = $data['phone'];
                        $answer['id_user'] =  $result['id'] ;
                        $this->db->update($this->register_answer, $answer,"id={$result['id']}");
//
                        echo json_encode(array('done' => array('done' => $result['uid'])), JSON_FORCE_OBJECT);

                    }
                    else
                    {


                     $stmt = $this->db->insert($this->table, array_diff_key($data,['about_company'=>"delete",'forAnswerThat'=>"delete",'after_video'=>"delete",'note'=>"delete",'day'=>"delete",'month'=>"delete",'year'=>"delete"]));
                      $last_id=$this->db->lastInsertId();
                        $_SESSION['username_member_r'] = $data['phone'];
                        $_SESSION['id_member_r'] = $last_id ;
                        $_SESSION['name_r'] = $data['name'];
                        $_SESSION['typeLogin'] = $data['login'];

                        $answer['phone'] = $data['phone'];
                        $answer['id_user'] =  $last_id ;
                        $this->db->insert($this->register_answer, $answer);
//                        setcookie("setLogin", openssl_encrypt($_SESSION['username_member_r'],"AES-128-ECB",HASH_PASSWORD_KEY).'#|'. $_SESSION['id_member_r'] ,time() + 31556926 , "/");

                    echo json_encode(array('done' => array('done' =>  $data['uid'])), JSON_FORCE_OBJECT);
                 }
                }

            } catch (Exception $e) {

                $this->error_form = $e->getMessage();
                echo json_encode(array('error' => json_decode($this->error_form)), JSON_FORCE_OBJECT);
            }

        }
    }


    function phone()
    {
           $phone= $_POST['phone'];
         $stmt=$this->db->prepare("SELECT *FROM `register_user` WHERE `phone`=?  AND `xc` =1");
         $stmt->execute(array($phone));
        if ($stmt->rowCount()>0)
        {
            $result=$stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['username_member_r'] = $result['phone'];
            $_SESSION['id_member_r'] =  $result['id'];
            $_SESSION['name_r'] = $result['name'];
            $_SESSION['typeLogin'] = $result['login'];

            echo json_encode(array('done' => array('done' => $result['uid'],'first_name' => $result['first_name'])), JSON_FORCE_OBJECT);
        }else{
            $this->error_form=json_encode(array('error'=>  'error' ));
            echo json_encode(array('error' => json_decode($this->error_form)), JSON_FORCE_OBJECT);
        }

    }



    function login_customer($id)
    {

    	if ($this->handleLogin())
		{

        $stmt=$this->db->prepare("SELECT *FROM `register_user` WHERE `id`=? ");
        $stmt->execute(array($id));
        if ($stmt->rowCount()>0)
        {
            $result=$stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['username_member_r'] = $result['phone'];
            $_SESSION['id_member_r'] =  $result['id'];
            $_SESSION['name_r'] = $result['name'];
            $_SESSION['typeLogin'] = $result['login'];
//            setcookie("setLogin", openssl_encrypt($_SESSION['username_member_r'],"AES-128-ECB",HASH_PASSWORD_KEY).'#|'. $_SESSION['id_member_r'] ,time() + 31556926 , "/");

            $this->lightRedirect(url,0);

        }

	}
    }


    function chphone($phone)
    {

        $stmt=$this->db->prepare("SELECT *FROM `register_user` WHERE `phone`=? AND `xc` =1");
        $stmt->execute(array($phone));
        if ($stmt->rowCount()>0)
        {
           echo 'found';
        }

    }

    function c_uid($length)
    {
        $key = $this->generateRandomString($length);
        $c_uid = $this->db->prepare("SELECT * from  {$this->table} WHERE `uid`=?  ");
        $c_uid->execute(array($key));
        if ($c_uid->rowCount() > 0) {
            $this->c_uid($length);
        } else {
            return $key;
        }

    }


    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }


    function add_customers($phone=null)
    {
        $this->checkPermit('add_customer','registration');
        $this->adminHeaderController($this->langControl('add_customer'));



        require ($this->render($this->folder,'html','add','php'));
        $this->adminFooterController();
    }


    function form_add_customer()
    {

        $this->checkPermit('add_customer','registration');
        if (true) {
            try {
                $form = new  Form();

                $form->post('name')
                    ->val('strip_tags');

                $form->post('phone')
                    ->val('strip_tags');



                $form->submit();
                $data = $form->fetch();


                $data['uid'] = $this->c_uid(6);


                if (!empty($data['name']) || !empty($data['phone']) ) {
                    if (empty($data['phone'])) {
                        $data['phone'] = $data['uid'];
                        $data['username'] = $data['uid'];
                    } else
                    {
                        $data['username']=$data['phone'];
                    }

                    $data['year']=date('Y',time());
                    $data['date']=time();
                    $data['login']='website';
                    $data['country']='العراق';
                    $data['xc']=0;

                    $stmt = $this->db->insert($this->table,$data);
                    $last_id=$this->db->lastInsertId();
                    $this->logoutNow();
                    if (empty($data['phone'])) {
                        $_SESSION['username_member_r'] = $data['uid'];
                    } else
                    {
                        $_SESSION['username_member_r']=$data['phone'];
                    }

                    $_SESSION['id_member_r'] = $last_id ;
                    $_SESSION['name_r'] = $data['name'];
                    $_SESSION['typeLogin'] = $data['login'];
                    echo json_encode(array('done' => array('done' => 'done')), JSON_FORCE_OBJECT);

                }else
                {
                    echo json_encode(array('error' => array('error' => 'يجب كتابة الاسم او الرقم')), JSON_FORCE_OBJECT);

                }

            } catch (Exception $e) {

                $this->error_form = $e->getMessage();
                echo json_encode(array('error' => array('error' => 'يجب كتابة الاسم او الرقم')), JSON_FORCE_OBJECT);
            }

        }

    }


    function logoutNow()
    {
        setcookie("setLogin", null,time() + 31556926  , "/");
        unset($_SESSION['username_member_r']);
        unset($_SESSION['id_member_r']);
        unset($_SESSION['name_r']);
        unset($_SESSION['typeLogin']);
    }



    function search()
    {
        $this->checkPermit('search','registration');
        $this->adminHeaderController($this->langControl('add_customer'));



        require ($this->render($this->folder,'html','search','php'));
        $this->adminFooterController();

    }

    function ch_search_c()
    {

        $this->checkPermit('add_customer','registration');
        if (true) {
            try {
                $form = new  Form();

                $form->post('name')
                    ->val('strip_tags');

                $form->submit();
                $data = $form->fetch();




                $stmt=$this->db->prepare("SELECT *FROM `register_user` WHERE `phone`=?");
                $stmt->execute(array($data['name']));
                if ($stmt->rowCount()>0)
                {

                    $result=$stmt->fetch(PDO::FETCH_ASSOC);
                    $stmt2 = $this->db->prepare("SELECT *FROM `cart_shop` WHERE `buy` = 1 AND  `status` = 0 AND `id_member_r` = ? GROUP BY `id_member_r`  ORDER BY `date_req` ASC ");
                    $stmt2->execute(array($result['id']));

                    if ($stmt2->rowCount() > 0)
                    {
                        echo json_encode(array('doner' => array('doner' => $result['id'])), JSON_FORCE_OBJECT);

                    }else
                    {
                        echo json_encode(array('done' => array('done' => $result['id'])), JSON_FORCE_OBJECT);

                    }


                }else
                {
                    echo json_encode(array('error' => array('error' =>$data['name'])), JSON_FORCE_OBJECT);

                }

            } catch (Exception $e) {

                $this->error_form = $e->getMessage();
                echo json_encode(array('f' => array('f' => 'حدث خطا')), JSON_FORCE_OBJECT);
            }

        }

    }

    function byphone()
    {

        if ($this->handleLogin()) {
            $uuid = $this->isUuid();
            $phone = trim($_POST['phone']);

            $stmt = $this->db->prepare("SELECT *FROM `register_user` WHERE `phone`=? limit 1");
            $stmt->execute(array($phone));
            $result = $stmt->fetch(PDO::FETCH_ASSOC);


            $id_user = $result['id'];

            $dollar=0;
            $stmt=$this->db->prepare("SELECT *FROM `dollar_price`  WHERE `active` = 1  ORDER BY `id` DESC  LIMIT 1" );
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                $resultDollar = $stmt->fetch(PDO::FETCH_ASSOC);
                $dollar=$resultDollar['dollar'];
            }

            if (!empty($result)) {
                if ($_SESSION['direct'] == 3)
                {
                    $stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`prepared` = ?,`dollar_exchange`=?  WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                    $stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,1,$dollar, $uuid));
                }else{
                    $stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`dollar_exchange`=? WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                    $stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,$dollar, $uuid));

                }


                $mobile = new mobile();

                $stmt_date = $this->db->prepare("UPDATE `cart_shop` SET `date_req` = ?  WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                $stmt_date->execute(array(time(), $id_user));

                $stmt1 = $mobile->getAllContentFromCar_new($id_user);

                while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {


                    $table=$row['table'] ;
                    if ($table== 'mobile') {
                        $excel = 'excel';
                    }else   if ($table== 'product_savers') {
                        $excel = 'excel_savers';
                        $table = 'savers';
                    } else {
                        $excel = 'excel_' . $table;
                    }


                    $number = $row['number'];
                    $stmt = $this->db->prepare("UPDATE  `{$excel}` SET `quantity`=`quantity` - {$number} WHERE  `code`=?  ");
                    $stmt->execute(array($row['code']));


                    $stmtChCodeConform = $this->db->prepare("SELECT *FROM location_confirm WHERE code =? AND model=? AND quantity > {$number}");
                    $stmtChCodeConform->execute(array($row['code'],$table ));
                    if ($stmtChCodeConform->rowCount() > 0) {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=quantity - {$number} ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }else
                    {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=0 ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }




                    $stmt_get_item = $this->db->prepare("SELECT *FROM `{$row['table']}` WHERE id = ?  LIMIT 1");
                    $stmt_get_item->execute(array($row['id_item']));
                    $item = $stmt_get_item->fetch();
                    $row['title'] = $item['title'];
                    $row['img'] = $this->save_file . $row['image'];

                }



             /*   $x = $this->db->prepare("SELECT *FROM `cart_shop` WHERE `id_member_r`=? AND  `prepared` = 0 AND `accountant`=0 AND `buy` =1 ");
                $x->execute(array($id_user));
                if ($x->rowCount() > 0) {

                    $stmtNb = $this->db->prepare("SELECT *FROM `cart_shop` WHERE `id_member_r`=? AND `prepared` = 0  AND `accountant`=0 AND `buy` =1  order by `number_bill` DESC LIMIT 1");
                    $stmtNb->execute(array($id_user));
                    if ($stmtNb->rowCount() > 0) {
                        $r = $stmtNb->fetch(PDO::FETCH_ASSOC);
                        $number_bill = $r['number_bill'];
                    }

                } else {

                    $stmtNb = $this->db->prepare("SELECT *FROM `cart_shop`  ORDER BY `number_bill` DESC   LIMIT 1");
                    $stmtNb->execute();
                    if ($stmtNb->rowCount() > 0) {
                        $r = $stmtNb->fetch(PDO::FETCH_ASSOC);
                        $number_bill = $r['number_bill'] + 1;
                    } else {
                        $number_bill = 1;
                    }
                }
                */
                $number_bill=$this->getNumberBill(4);


                $stmt1 = $this->db->prepare("UPDATE `cart_shop` SET `buy` = 1 ,`number_bill`=? WHERE `id_member_r`=? AND `buy` = 0 ");
                $stmt1->execute(array($number_bill, $id_user));

                $stmt2 = $this->db->prepare("UPDATE `register_user` SET `date_req` =  ?  WHERE `id` = ?  ");
                $stmt2->execute(array(time(), $id_user));


                $stmtt=$this->db->prepare("SELECT *FROM `cart_shop` WHERE   `number_bill` = ? ");
                $stmtt->execute(array($number_bill ));
                $oldData=array();
                while ($rowt = $stmtt->fetch(PDO::FETCH_ASSOC))
                {
                    $oldData[]=$rowt;
                }

                if ($_SESSION['direct']==3)
                {
                    $trace = new trace(); $trace->addtrace('cart_shop','محاسب مباشر- اضافة طلب جيد -  بستخدام رفم الهاتف      ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المحاسب المباشر رقم الفاتورة ' . $number_bill,$number_bill);
                }else if($_SESSION['direct']==2){
                    $trace = new trace(); $trace->addtrace('cart_shop','مجهز مباشر- اضافة طلب جيد -    بستخدام رفم الهاتف       ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المجهز المباشر رقم الفاتورة ' . $number_bill,$number_bill);

                }else
                {
                    $trace = new trace(); $trace->addtrace('cart_shop','بائع مباشر- اضافة طلب جيد -     بستخدام رفم الهاتف      ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة البائع المباشر رقم الفاتورة ' . $number_bill,$number_bill);

                }




                echo $_SESSION['direct'];
                Session::set('uuid', $this->uuid(4));
            }
        }
    }

    function qr($uid)
    {

		if (isset($_SESSION['loggedIn'])){


            $uuid = $this->isUuid();


            $stmt = $this->db->prepare("SELECT *FROM `register_user` WHERE `uid`=? limit 1");
            $stmt->execute(array($uid));
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $id_user = $result['id'];

            $dollar=0;
            $stmt=$this->db->prepare("SELECT *FROM `dollar_price`  WHERE `active` = 1  ORDER BY `id` DESC  LIMIT 1" );
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                $resultDollar = $stmt->fetch(PDO::FETCH_ASSOC);
                $dollar=$resultDollar['dollar'];
            }


            if (!empty($result)) {
				if ($_SESSION['direct'] == 3)
				{
					$stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`prepared` = ?,`dollar_exchange`=?  WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
					$stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,1,$dollar, $uuid));
				}else{
					$stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`dollar_exchange`=? WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
					$stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,$dollar, $uuid));

				}



				$mobile = new mobile();

                $stmt_date = $this->db->prepare("UPDATE `cart_shop` SET `date_req` = ?  WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                $stmt_date->execute(array(time(), $id_user));

                $stmt1 = $mobile->getAllContentFromCar_new($id_user);

                while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {


                    $table=$row['table'] ;
                    if ($table== 'mobile') {
                        $excel = 'excel';
                    }else   if ($table== 'product_savers') {
                        $excel = 'excel_savers';
                        $table = 'savers';
                    } else {
                        $excel = 'excel_' . $table;
                    }


                    $number = $row['number'];
                    $stmt = $this->db->prepare("UPDATE  `{$excel}` SET `quantity`=`quantity` - {$number} WHERE  `code`=?  ");
                    $stmt->execute(array($row['code']));

                    $stmtChCodeConform = $this->db->prepare("SELECT *FROM location_confirm WHERE code =? AND model=? AND quantity > {$number}");
                    $stmtChCodeConform->execute(array($row['code'],$table ));
                    if ($stmtChCodeConform->rowCount() > 0) {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=quantity - {$number} ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }else
                    {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=0 ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }




                    $stmt_get_item = $this->db->prepare("SELECT *FROM `{$row['table']}` WHERE id = ?  LIMIT 1");
                    $stmt_get_item->execute(array($row['id_item']));
                    $item = $stmt_get_item->fetch();
                    $row['title'] = $item['title'];
                    $row['img'] = $this->save_file . $row['image'];

                }


                $number_bill=$this->getNumberBill(4);

                $stmt1 = $this->db->prepare("UPDATE `cart_shop` SET `buy` = 1 ,`number_bill`=? WHERE `id_member_r`=? AND `buy` = 0 ");
                $stmt1->execute(array($number_bill, $id_user));

                $stmt2 = $this->db->prepare("UPDATE `register_user` SET `date_req` =  ?  WHERE `id` = ?  ");
                $stmt2->execute(array(time(), $id_user));




				$stmtt=$this->db->prepare("SELECT *FROM `cart_shop` WHERE   `number_bill` = ? ");
				$stmtt->execute(array($number_bill ));
				$oldData=array();
				while ($rowt = $stmtt->fetch(PDO::FETCH_ASSOC))
				{
					$oldData[]=$rowt;
				}

				if ($_SESSION['direct']==3)
				{
					$trace = new trace(); $trace->addtrace('cart_shop','محاسب مباشر- اضافة طلب جيد -  بستخدام تقنية QR  ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المحاسب المباشر رقم الفاتورة ' . $number_bill,$number_bill);
				}else if($_SESSION['direct']==2){
					$trace = new trace(); $trace->addtrace('cart_shop','مجهز مباشر- اضافة طلب جيد - بستخدام تقنية QR ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المجهز المباشر رقم الفاتورة ' . $number_bill,$number_bill);

				}else
				{
					$trace = new trace(); $trace->addtrace('cart_shop','بائع مباشر- اضافة طلب جيد -  بستخدام تقنية QR  ',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة البائع المباشر رقم الفاتورة ' . $number_bill,$number_bill);

				}


				Session::set('uuid', $this->uuid(4));

			}
            require($this->render($this->folder, 'html', 'qr', 'php'));
        }else
		{

			$stmt = $this->db->prepare("SELECT *FROM `register_user` WHERE `uid`=? limit 1");
			$stmt->execute(array($uid));
			if ($stmt->rowCount()>0)
			{
				$result=$stmt->fetch(PDO::FETCH_ASSOC);
				$_SESSION['username_member_r'] = $result['phone'];
				$_SESSION['id_member_r'] =  $result['id'];
				$_SESSION['name_r'] = $result['name'];
				$_SESSION['typeLogin'] = $result['login'];
//				setcookie("setLogin", openssl_encrypt($_SESSION['username_member_r'],"AES-128-ECB",HASH_PASSWORD_KEY).'#|'. $_SESSION['id_member_r'] ,time() + 31556926 , "/");

				$this->lightRedirect(url,0);

			}else
			{
				echo 'الزبون غبر مسجل!!';
			}

		}
    }

    function new_customers()
    {
        if ($this->handleLogin()) {

            $uuid = $this->isUuid();
            $name = trim(strip_tags($_POST['name']));
            $phone = trim($_POST['phone']);


            $data['uid'] = $this->c_uid(6);


            $data['name'] = $name;
            $data['username'] = $phone;
            $data['phone'] = $phone;
            $data['year'] = date('Y', time());
            $data['date'] = time();
            $data['login'] = 'website';
            $data['country'] = 'العراق';
            $data['xc'] = 0;

            $stmtx = $this->db->insert($this->table, $data);
            $last_id = $this->db->lastInsertId();


            $stmt = $this->db->prepare("SELECT *FROM `register_user` WHERE `id`=? limit 1");
            $stmt->execute(array($last_id));
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            $id_user = $result['id'];

            $dollar=0;
            $stmt=$this->db->prepare("SELECT *FROM `dollar_price`  WHERE `active` = 1  ORDER BY `id` DESC  LIMIT 1" );
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                $resultDollar = $stmt->fetch(PDO::FETCH_ASSOC);
                $dollar=$resultDollar['dollar'];
            }


            if (!empty($result)) {

                if ($_SESSION['direct'] == 3)
                {
                    $stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`prepared`=?,`dollar_exchange`=? WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                    $stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,1,$dollar, $uuid));
                }else{
                    $stmt_uuid = $this->db->prepare("UPDATE `cart_shop` SET `date`=?,`id_member_r` = ? ,`direct`=? ,`user_direct`=?,`dollar_exchange`=? WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                    $stmt_uuid->execute(array(time(),$id_user, $_SESSION['direct'], $this->userid,$dollar, $uuid));
                }




                $mobile = new mobile();

                $stmt_date = $this->db->prepare("UPDATE `cart_shop` SET `date_req` = ?  WHERE `id_member_r`=? AND `buy` = 0 AND `status`=0");
                $stmt_date->execute(array(time(), $id_user));

                $stmt1 = $mobile->getAllContentFromCar_new($id_user);

                while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {



                    $table=$row['table'] ;
                    if ($table== 'mobile') {
                        $excel = 'excel';
                    }else   if ($table== 'product_savers') {
                        $excel = 'excel_savers';
                        $table = 'savers';
                    } else {
                        $excel = 'excel_' . $table;
                    }


                    $number = $row['number'];
                    $stmt = $this->db->prepare("UPDATE  `{$excel}` SET `quantity`=`quantity` - {$number} WHERE  `code`=?  ");
                    $stmt->execute(array($row['code']));


                    $stmtChCodeConform = $this->db->prepare("SELECT *FROM location_confirm WHERE code =? AND model=? AND quantity > {$number}");
                    $stmtChCodeConform->execute(array($row['code'],$table ));
                    if ($stmtChCodeConform->rowCount() > 0) {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=quantity - {$number} ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }else
                    {
                        $stmtExcel_conform = $this->db->prepare("UPDATE location_confirm SET  quantity=0 ,`date`=?  WHERE code =? AND  model=?");
                        $stmtExcel_conform->execute(array(time(),$row['code'], $table));
                    }





                    $stmt_get_item = $this->db->prepare("SELECT *FROM `{$row['table']}` WHERE id = ?  LIMIT 1");
                    $stmt_get_item->execute(array($row['id_item']));
                    $item = $stmt_get_item->fetch();
                    $row['title'] = $item['title'];
                    $row['img'] = $this->save_file . $row['image'];

                }


              /*  $x = $this->db->prepare("SELECT *FROM `cart_shop` WHERE `id_member_r`=? AND  `prepared` = 0 AND `accountant`=0 AND `buy` =1 ");
                $x->execute(array($id_user));
                if ($x->rowCount() > 0) {

                    $stmtNb = $this->db->prepare("SELECT *FROM `cart_shop` WHERE `id_member_r`=? AND `prepared` = 0  AND `accountant`=0 AND `buy` =1  order by `number_bill` DESC LIMIT 1");
                    $stmtNb->execute(array($id_user));
                    if ($stmtNb->rowCount() > 0) {
                        $r = $stmtNb->fetch(PDO::FETCH_ASSOC);
                        $number_bill = $r['number_bill'];
                    }

                } else {

                    $stmtNb = $this->db->prepare("SELECT *FROM `cart_shop`  ORDER BY `number_bill` DESC   LIMIT 1");
                    $stmtNb->execute();
                    if ($stmtNb->rowCount() > 0) {
                        $r = $stmtNb->fetch(PDO::FETCH_ASSOC);
                        $number_bill = $r['number_bill'] + 1;
                    } else {
                        $number_bill = 1;
                    }
                }
*/

                $number_bill=$this->getNumberBill(4);

                $stmt1 = $this->db->prepare("UPDATE `cart_shop` SET `buy` = 1 ,`number_bill`=? WHERE `id_member_r`=? AND `buy` = 0 ");
                $stmt1->execute(array($number_bill, $id_user));

                $stmt2 = $this->db->prepare("UPDATE `register_user` SET `date_req` =  ?  WHERE `id` = ?  ");
                $stmt2->execute(array(time(), $id_user));



                $stmtt=$this->db->prepare("SELECT *FROM `cart_shop` WHERE   `number_bill` = ? ");
                $stmtt->execute(array($number_bill ));
                $oldData=array();
                while ($rowt = $stmtt->fetch(PDO::FETCH_ASSOC))
                {
                    $oldData[]=$rowt;
                }

                if ($_SESSION['direct']==3)
                {
                    $trace = new trace(); $trace->addtrace('cart_shop','محاسب مباشر- اضافة طلب جيد - زبون جيد فقط لهذة الفاتورة',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المحاسب المباشر رقم الفاتورة ' . $number_bill,$number_bill);
                }else if($_SESSION['direct']==2){
                    $trace = new trace(); $trace->addtrace('cart_shop','مجهز مباشر- اضافة طلب جيد - زبون جيد فقط لهذة الفاتورة',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة المجهز المباشر رقم الفاتورة ' . $number_bill,$number_bill);

                }else
                {
                    $trace = new trace(); $trace->addtrace('cart_shop','بائع مباشر- اضافة طلب جيد - زبون جيد فقط لهذة الفاتورة',json_encode($oldData),json_encode(array()),' اضافة طلب بواسطة البائع المباشر رقم الفاتورة ' . $number_bill,$number_bill);

                }





                echo $_SESSION['direct'];
                Session::set('uuid', $this->uuid(4));
            }
        }
    }


    function login_qr($uid)
	{
		$stmt = $this->db->prepare("SELECT *FROM `register_user` WHERE `uid`=? limit 1");
		$stmt->execute(array($uid));
		if ($stmt->rowCount()>0)
		{
			$result=$stmt->fetch(PDO::FETCH_ASSOC);
			$_SESSION['username_member_r'] = $result['phone'];
			$_SESSION['id_member_r'] =  $result['id'];
			$_SESSION['name_r'] = $result['name'];
			$_SESSION['typeLogin'] = $result['login'];
//			setcookie("setLogin", openssl_encrypt($_SESSION['username_member_r'],"AES-128-ECB",HASH_PASSWORD_KEY).'#|'. $_SESSION['id_member_r'] ,time() + 31556926 , "/");

			$this->lightRedirect(url,0);

		}else
		{
			echo 'الزبون غبر مسجل!!';
		}


	}




}