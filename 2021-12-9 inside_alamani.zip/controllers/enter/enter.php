<?php

class enter extends Controller
{
	function __construct()
	{
		parent::__construct();
	}


	function index()
	{




		$city=array(
			'بغداد',
			'كربلاء',
			'بابل',
			'النجف',
			'ميسان',
			'الأنبار',
			'أربيل',
			'البصرة',
			'دهوك',
			'القادسية',
			'ديالى',
			'ذي قار',
			'السليمانية',
			'صلاح الدين',
			'كركوك',
			'المثنى',
			'نينوى',
			'واسط',
		);








		require($this->render($this->folder, 'html', 'index', 'php'));

	}


	function index2()
	{




		$city=array(
			'بغداد',
			'كربلاء',
			'بابل',
			'النجف',
			'ميسان',
			'الأنبار',
			'أربيل',
			'البصرة',
			'دهوك',
			'القادسية',
			'ديالى',
			'ذي قار',
			'السليمانية',
			'صلاح الدين',
			'كركوك',
			'المثنى',
			'نينوى',
			'واسط',
		);



		 require($this->render($this->folder, 'html', 'index2', 'php'));

	}

	function rprice()
	{

		if (isset($_POST['submit']))
		{

		  	$qr=$_POST['qr'];
			$link=explode('/',$qr);
			$code= end($link);

			 $stmtqr=$this->db->prepare("SELECT *FROM register_user WHERE uid=? ");
			$stmtqr->execute(array($code));
			if ($stmtqr->rowCount() > 0)
			{
				$result=$stmtqr->fetch(PDO::FETCH_ASSOC);
				$_SESSION['username_member_r'] = $result['phone'];
				$_SESSION['id_member_r'] =  $result['id'];
				$_SESSION['name_r'] = $result['name'];
				$_SESSION['typeLogin'] = $result['login'];
				echo 'true';
			}else{
				echo 'rqr';
			}

		}else
		{
			echo 'rqr';
		}



	}




}