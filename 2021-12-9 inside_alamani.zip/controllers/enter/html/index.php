<!DOCTYPE html>
<meta property="og:type" content="website"/>
<html dir="<?php echo $this->dirSite ?>">
<head>
	<meta charset="UTF-8">
	<!--    <meta name="viewport" content="width=device-width, initial-scale=0, maximum-scale=0" />-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

	<title> تسجيل الدخول </title>
	<link rel="icon"   href="<?php echo $this->static_file_site ?>/image/site/logo_notif.png">


	<!--jquery -->
	<script src="<?php echo $this->static_file_site ?>/js/jquery.min.js"></script>

	<!--bootstrap-->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/bootstrap/css/bootstrap.min.css" >
	<script src="<?php echo $this->static_file_site ?>/bootstrap/js/popper.min.js"></script>
	<script src="<?php echo $this->static_file_site ?>/bootstrap/js/bootstrap.min.js"  ></script>

	<!--css range-->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/range_input2/jquery.range.css">

	<!--custom css -->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/css/default1.css"/>

	<!--custom js-->
	<script src="<?php echo $this->static_file_site ?>/js/custom.js"></script>


	<!--bootstrap-toggle-->
	<link href="<?php echo $this->static_file_site ?>/bootstrap/toggle/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="<?php echo $this->static_file_site ?>/bootstrap/toggle/js/bootstrap-toggle.min.js"></script>

	<!--upload file-->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/dist2/font-awesome.min.css"/>


	<!--dataTables-->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/datatable/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/datatable/css/dataTables.bootstrap4.min.css">
	<script type="text/javascript" src="<?php echo $this->static_file_site ?>/datatable/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->static_file_site ?>/datatable/js/dataTables.bootstrap4.min.js"></script>


	<!--editor css -->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/editor/froala/css/froala_style.css"/>


	<!--      pagenation-->
	<script src="<?php echo $this->static_file_control ?>/js/pagenation/twbsPagination.js"></script>
	<script src="<?php echo $this->static_file_control ?>/zoom/jquery.elevatezoom.js"></script>

	<!--    swiper-->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/swiper/swiper.min.css">
	<script src="<?php echo $this->static_file_site ?>/js/qrcode.min.js"></script>

	<!--  range -->
	<link rel="stylesheet" href="<?php echo $this->static_file_site ?>/range/jquery-ui.css" type="text/css" media="all" />
	<script src="<?php echo $this->static_file_site ?>/range/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?php echo $this->static_file_site ?>/range/price_range_script.js"></script>





	<script>

        var myarr_non = ['NON','non','UNKNOWN','unknown','Unknown','Non','بلا','',' ','  '];

	</script>


	<style>

		@media  only screen and  (max-width: 980px) and  (min-width: 700px)
		{
			.container {
				max-width: 970px;
			}

			.style_btn_like_mb {
				width: 48%;
			}
			.comparison {
				width: 48%;
			}
			.xcartp {
				padding: 0 15px;
			}
		}


		@media  only screen and  (max-width: 700px) and  (min-width: 500px)
		{
			.container {
				max-width: 970px;
			}
		}
		@media (max-width: 570px)
		{
			.xcartp {
				padding: 0 15px;
				margin-bottom: 5px;
			}
		}


	</style>



</head>
<body   style="overflow-x: hidden;position: relative">

<div class="background_register">

	<div class="video_center_screen">
		<video  class="bg_video" autoplay muted loop id="myVideo">
			<source src="<?php echo $this->static_file_site ?>/image/site/bg.mp4" type="video/mp4">
			Your browser does not support HTML5 video.
		</video>
        <div class="opacity_video"></div>
	</div>
<div class="control_from_register">
<div class="container-fluid">
	<div class="row justify-content-end">
		<div class="col-lg-7 col-md-7   col-sm-7    col-7  ">
            <div class="container_from">

                <div id="carouselExampleControls"    class="carousel slide" data-ride="carousel"   data-interval="false"  data-pause="hover" data-wrap="false">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                             <div class="real_screen">
                                 شاشة الحقيقة
                             </div>
                            <div class="text_start">
                                <div>عند التسجيل من خلال شاشة الحقيقة ولمرة واحدة فقط،</div>
                                <div>
                                    ستتعرف كيف تسعى شركة الأماني على تقديم السعر الأنسب دوماً، وفق معايير تعهدنا بتقديمها لجميع زبائننا الكرام، كذلك ستحصل على حساب (مجاناً) في السوق الإلكتروني لشركة الأماني، والذي سيوفر سهولة ومتعة في التسوّق أثناء زيارتك هذه وزياراتك القادمة.

                                </div>
                            </div>


                            <a   class="btn next_slider" href="#carouselExampleControls" role="button" data-slide="next">
                               مستعد..لنبدأ
                            </a>
                        </div>
                        <div class="carousel-item xback ">
                            <form action="<?php  echo url  ?>/customers/phone"  method="post"  id="search_phone"   class="was-validated">

                            <div class="search_phone">

                                    <div class="row align-items-end">
                                        <div class="col"  >
                                            <label style="font-size: 20px" for="search_phone">ادخل رقم الهاتف</label>
                                            <input class="form-control is-valid"  onkeyup="goPhoneToTextbox(this)"  type="number" min="07000000000" max="07999999999" name="phone"  autocomplete="off" placeholder="ادخل رقم الهاتف" id="search_phone" required>
                                        </div>

                                        <div class="col-auto" style="padding-right: 0" >
                                            <button type="button" class="btn readQrbtn" onclick="select_qr()" data-toggle="modal" data-target="#exampleModal_qr">
                                                <i class="fa fa-qrcode"></i>
                                            </button>
                                        </div>

                                    </div>
                                <div class="text_phone">
                                    ستحصل على رمز QR اذا كان رقم هاتفك مسجل مسبقا,او قم بالتسجيل شكرا.
                                </div>

                            </div>

                            <div class="control_slider_regiser">
                                <div class="row justify-content-between">
                                    <div class="col-auto">
                                        <a class="btn back_layer" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <i class="fa fa-caret-right"></i> <span> السابق </span>
                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" name="submit" class="btn next_layer"  >
                                           <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>

                                        <a class="btn next_layer after_phone" hidden href="#carouselExampleControls" role="button" data-slide="next">
                                           <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            </form>

                        </div>
                        <form action="<?php  echo url  ?>/customers/form"  method="post"  id="idFormReg"   class="was-validated">

<!--                            form-->
                        <div class="carousel-item xnext">
                            <div class="text_register"> تسجيل </div>

                              <div class="field_form">

                                                <div class="form-group row">

                                                    <div class="col-12">
                                                        <input   autocomplete="off"   type="text" class="form-control is-invalid"  onkeyup="checkfield1()"  name="first_name" id="first_name" placeholder="الاسم  " required >
                                                    </div>
                                                </div>




                                                <div class="form-group row">

                                                    <div class="col-12">
                                                        <input   autocomplete="off"   type="text" class="form-control "  onkeyup="checkfield1()"   name="title" id="title" placeholder="اللقب"  required>
                                                    </div>
                                                </div>


                                                <div class="form-group row">

                                                    <div class="col-12">

                                                        <div class="row">
                                                            <div class="col-lg-4 col-md-4 col-sm-4 col-4">

                                                                <select  name="day" class="brth form-control ">
                                                                    <option value="">اليوم</option>
                                                                    <?php   for($i=1 ; $i <=31 ;$i++) { ?>
                                                                    <option value="<?php echo $i ?>"><?php echo $i ?></option>
                                                                    <?php  } ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-4 col-md-4 col-sm-4 col-4">

                                                                <select  name="month" class="brth form-control ">
                                                                    <option value="">الشهر</option>
																	<?php   for($x=1 ; $x <=12 ;$x++) { ?>
                                                                        <option value="<?php echo $x ?>"><?php echo $x ?></option>
																	<?php  } ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-4 col-md-4 col-sm-4 col-4">
                                                                <input  autocomplete="off"   type="number" class="form-control xcolalich no_required" name="year"   id="year" max="<?php   echo  date('Y',time()) ?>"  min="1950"   placeholder="السنه"  >
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>



                                                <style>

                                                    .was-validated  .brth.form-control:valid
                                                    {
                                                      background-image: none;
                                                        padding-left: unset;
                                                    }

                                                    .form-control.no_required {
                                                        border-color: #ced4da !important;
                                                        padding-left:unset !important;
                                                        background-image:unset !important;

                                                    }

                                                    .withModelRegister
                                                    {
                                                        max-width: unset !important;
                                                        width: 100% !important;
                                                        padding: 0 20px !important;
                                                    }
                                                </style>




                                    </div>
                            <div class="control_slider_regiser btn_control_ly3">

                                <div class="row justify-content-between">
                                    <div class="col-auto">
                                        <a class="btn back_layer" onclick="set_back_layer()"   >
                                            <i class="fa fa-caret-right"></i> <span> السابق </span>
                                        </a>
                                    </div>
                                    <div class="col-auto">

                                        <button class="btn next_layer ff1" disabled="disabled"  href="#carouselExampleControls" role="button" data-slide="next">
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>
                                    </div>
                                </div>

                            </div>



                        </div>

                        <div class="carousel-item">
                            <div class="text_register"> تسجيل </div>

                              <div class="field_form">


                                    <div class="form-group row align-items-center">

                                        <div class="col-12">
                                            <div class="chphone"></div>
                                            <input type="number" class="form-control"    onkeyup="showResult(this.value);checkfield2()" autocomplete="off" name="phone"  min="07000000000" max="07999999999"  id="phone" placeholder="رقم الهاتف"  required>
                                        </div>
                                    </div>

                                    <div class="form-group row">

                                        <div class="col-12">
                                            <select name="city" onchange="checkfield2()" id="city" class="custom-select" required>
                                                <option value="" hidden="">حدد المحافظة</option>
                                                <option value="أربيل">أربيل</option>
                                                <option value="الأنبار">الأنبار</option>
                                                <option value="بابل">بابل</option>
                                                <option value="بغداد">بغداد</option>
                                                <option value="البصرة">البصرة</option>
                                                <option value="دهوك">دهوك</option>
                                                <option value="القادسية">القادسية</option>
                                                <option value="ديالى">ديالى</option>
                                                <option value="ذي قار">ذي قار</option>
                                                <option value="السليمانية">السليمانية</option>
                                                <option value="صلاح الدين">صلاح الدين</option>
                                                <option value="كركوك">كركوك</option>
                                                <option selected value="كربلاء المقدسة">كربلاء المقدسة</option>
                                                <option value="المثنى">المثنى</option>
                                                <option value="ميسان">ميسان</option>
                                                <option value="النجف الأشرف">النجف الأشرف</option>
                                                <option value="نينوى">نينوى</option>
                                                <option value="واسط">واسط</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-group row">

                                        <div class="col-12">
                                            <input  autocomplete="off"   type="text" class="form-control "  onkeyup="checkfield2()" name="address" id="address" placeholder="الحي"  required>
                                        </div>
                                    </div>


                                    </div>
                            <div class="control_slider_regiser btn_control_ly3">

                                <div class="row justify-content-between">
                                    <div class="col-auto">
                                        <a class="btn back_layer" href="#carouselExampleControls" role="button" data-slide="prev">
                                        <i class="fa fa-caret-right"></i> <span> السابق </span>
                                        </a>
                                    </div>
                                    <div class="col-auto">

                                        <button class="btn next_layer ff2" disabled="disabled" href="#carouselExampleControls" role="button" data-slide="next">
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>
                                    </div>
                                </div>

                            </div>



                        </div>

<!--                            choose-->
                        <div class="carousel-item ONNo">


                            <div class="row">
                                <div class="col-12">
                                    <label for="about_company" class="col-form-label" style="font-size: 18px;margin-bottom: 5px">

                                        لاحظنا ان بعض زبائننا الكرام ليس لديهم معلومة عن المعنى الحقيقي لشعار شركتنا (جودة , ضمان , سعر مميز) فهل تعرف ماذا نقصد به؟

                                    </label>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="about_company" class="col-sm-3 col-form-label"> </label>
                                <div class="col-sm-9">

                                    <div class="custom-control custom-radio custom-control-inline yes_or_no">
                                        <input type="radio"  value="1" id="about_company1" name="about_company" required class="custom-control-input ">
                                        <label class="custom-control-label about_company_style" for="about_company1">نعم</label>
                                    </div>
                                    <div class="custom-control custom-radio custom-control-inline yes_or_no">
                                        <input type="radio" value="2" id="about_company2" name="about_company" required class="custom-control-input  ">
                                        <label class="custom-control-label about_company_style" for="about_company2">كلا</label>
                                    </div>

                                </div>
                            </div>


                            <div class="control_slider_regiser btn_control_ly4">

                                <div class="row justify-content-between">
                                    <div class="col-auto">
                                        <a class="btn back_layer" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <i class="fa fa-caret-right"></i> <span> السابق </span>
                                        </a>
                                    </div>
                                    <div class="col-auto">

                                        <button type="button" class="btn next_layer next_choose ff3" disabled href="#carouselExampleControls" role="button" data-slide="next">
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>

                                        <button type="button" class="btn next_layer open_video_fast ff3" disabled style="display: none"  onclick="gotoVideo()">
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>



                                    </div>
                                </div>

                            </div>

                        </div>
<!--                            choose-->
                        <div class="carousel-item ONNo">

                                <div class="forAnswerThat"  style="margin-bottom: 5px">
                                    احدى الاجوبة الاتية هي الحقيقة و التي تمثل المعنى الحقيقي للجودة و الضمان و السعر المميز اختر حسب معلوماتك
                                </div>

                                <div class="custom-control custom-radio custom-control-inline setForAnswer">
                                    <input type="radio"   value="1" id="forAnswerThat1" name="forAnswerThat" class="custom-control-input">
                                    <label class="custom-control-label " for="forAnswerThat1">
                                        1.	انك ستحصل على انسب سعر و افضل ضمان.

                                    </label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline setForAnswer">
                                    <input type="radio" value="2" id="forAnswerThat2" name="forAnswerThat" class="custom-control-input">
                                    <label class="custom-control-label" for="forAnswerThat2">
                                        2.	ستحصل على انسب سعر و افضل ضمان و الجودة تعني انك اشتريت جهاز لماركة مشهورة.

                                    </label>
                                </div>

                                <div class="custom-control custom-radio custom-control-inline setForAnswer">
                                    <input type="radio" value="3" id="forAnswerThat3" name="forAnswerThat" class="custom-control-input">
                                    <label class="custom-control-label" for="forAnswerThat3">

                                        3.	ستحصل على انسب سعر و افضل ضمان لجهاز غير مغشوش "اصلي" في زمن انتشر به الغش بشكل كبير جدا و خصوصا في عالم اجهزة الموبايل لان طرق الغش سهلة و مربحة جداً و تحتاج فقط لشخص غير ملتزم دينيا ليعمل بها و يكسب منها الاموال الحرام الطائلة و من تلك الطرق البسيطة هي استبدال ملحقات الاجهزة الاصلية بملحقات تجارية مشابهة للاصلية و اعادة اقفال كارتونة الجهاز بلاصق او نايلون يشابه لاصق و نايلون الجهاز الاصلي فيصبح فقط صاحب الاختصاص الذي لديه خبرة كافية يستطيع ان يميز الجهاز .
                                    </label>
                                </div>




                            <div class="control_slider_regiser btn_control_ly4">

                                <div class="row justify-content-between">
                                    <div class="col-auto">
                                        <a class="btn back_layer goback" href="#carouselExampleControls" role="button" data-slide="prev">
                                            <i class="fa fa-caret-right"></i> <span> السابق </span>
                                        </a>
                                    </div>
                                    <div class="col-auto">

                                        <button type="button" class="btn next_layer choose_1_2 ff4" disabled onclick="gotoVideo()"  >
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>

                                        <button name="submit"  type="submit" class="btn next_layer  choose3 ff4" disabled style="display: none" >
                                            <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                        </button>

                                    </div>
                                </div>

                            </div>

                        </div>

<!--                            video-->
                        <div class="carousel-item open_video">


                                <video preload="none" id="myvideo_play" class="video_view"  >
                                    <source src="<?php  echo  $this->static_file_site ?>/image/site/video1.mp4" type="video/mp4">
                                </video>



                                <div class="form-group row question_after_video">
                                    <label for="after_video" class="col-12 col-form-label text_after_video">

                                        بعد مشاهدتك فديو الحقيقة هل انت مقتنع تماما ان ليس من مصلحتك البحث عن السعر الافضل دوما في بيئة كثر بها الغش بشكل فضيع جدا و يتوجب عليك من الان اختيار مكان تثق به للشراء منه.
                                    </label>
                                    <div class="col-sm-9">

                                        <div class="custom-control custom-radio custom-control-inline yes_or_no">
                                            <input type="radio"  value="1" id="after_video1" name="after_video" class="custom-control-input fakeRadio">
                                            <label class="custom-control-label about_company_style"  for="after_video1">نعم</label>
                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline yes_or_no">
                                            <input type="radio" value="2" id="after_video2" name="after_video" class="custom-control-input fakeRadio">
                                            <label class="custom-control-label about_company_style" for="after_video2">كلا</label>
                                        </div>

                                    </div>
                                </div>



                                <div class="form-group row noteAfter_video">
                                    <label for="after_video" class="col-12 col-form-label">
                                        لماذا لست مقتنعاً اخبرنا كي نستفيد و نرتقي افضل بخدماتنا المقدمة لكم
                                    </label>
                                    <div class="col-12">

                                        <textarea rows="3" class="form-control" id="write_note" name="note"></textarea>
                                    </div>
                                </div>


                                <div class="control_slider_regiser">

                                    <div class="row justify-content-between">
                                        <div class="col-auto">
                                            <a class="btn back_layer" onclick="step2back()" href="#carouselExampleControls" role="button" data-slide="prev">
                                                <i class="fa fa-caret-right"></i> <span> السابق </span>
                                            </a>
                                        </div>
                                        <div class="col-auto">

                                            <button  name="submit" disabled type="submit" class="btn next_layer lsat_layer" >
                                                <span>التالي</span>  <i class="fa fa-caret-left"></i>
                                            </button>
                                        </div>
                                    </div>

                                </div>


                            </div>

                        </form>
                    </div>

                </div>

            </div>

		</div>

	</div>
</div>
</div>

</div>




<style>


    .text_after_video
    {
        font-size: 20px;
    }

    .control_slider_regiser {
        margin-top: 30px;
    }

     .btn.next_slider {
        background: #00abda;
        margin-top: 32px;
        border-radius: 36px;
        padding: 8px 23px;
        font-size: 25px;
        color: #fff;
        margin-right: 43px;
    }
     .btn.back_layer {
        background: #dc3545;
        margin-top: 23px;
        border-radius: 36px;
        padding: 8px 23px;
        font-size: 22px;
        color: #fff;

    }
    .btn.next_layer {
        background: #00abda;
        margin-top: 23px;
        border-radius: 36px;
        padding: 8px 23px;
        font-size: 22px;
        color: #fff;

    }
    .text_start
    {
        color: #ffffff;
        line-height: 1.7;
        font-family: Arial;
    }


    .real_screen {
        font-size: 55px;
        background: #CF2B8E;
        background: -webkit-linear-gradient(to left, #CF2B8E 0%, #FCB528 67%);
        background: -moz-linear-gradient(to left, #CF2B8E 0%, #FCB528 67%);
        background: linear-gradient(to left, #fb5695 0%, #fff258 67%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: bold;
    }

    .container_from {

        height: 385px;
        width: 100%;
        overflow: auto;
    }

	.background_register
	{

		border: 1px solid;
		height: 100%;
		position: fixed;
		width: 100%;
		background: black;


	}

	.background_register .video_center_screen
	{
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		background: blue;
		height: 100%;
        background-image: url(<?php echo $this->static_file_site ?>/image/site/bg.gif);
        background-repeat: no-repeat;
        background-position: right;
    }

    .opacity_video
    {
        position: absolute;
        width: 100%;
        height: 100%;
        z-index: 1;
        background: #000000eb;
        opacity: 1;
    }

	.background_register .video_center_screen .bg_video
	{
		width: 100%;
        z-index: 11;
	}
.control_from_register
{

	position: absolute;
	top: 0;
	width: 100%;
	height: 100%;
	display: flex;
	align-items: center;
    z-index: 1111;
    color: #ffffff;
}

    

</style>




<style>






    .search_phone .text_phone {
        font-size: 23px;
        margin-top: 53px;
    }


    input#search_phone {
        height: 50px;
        font-size: 20px;
    }

    button#btn_search_phone {
        background: #ffc107;
        color: #ffff;
        padding: 0 26px;
        height: 50px;
        border: 0;
        font-size: 26px;
        border-radius: 10px 0 0 10px;
    }

    .field_form input,
    .field_form textarea,
    .field_form select
    {
        height: 50px;
        font-size: 20px;
    }

    .xphonea
    {
        border: 1px solid red !important;
        box-shadow: 0 0 0 0.2rem rgba(167, 76, 40, 0.25) !important;

    }

.btn_control_ly3
{
    margin-top: 0;
}
.btn_control_ly4
{
    margin-top: 0;
}

     .xmarg
    {
      margin-bottom: 0;
    }

    .text_register {
        font-size: 30px;
        margin-bottom: 12px;
    }

    .setForAnswer {
        margin-bottom: 5px;
        border: 1px solid #bdbdbd;
        padding: 5px 34px 3px 0;
        border-radius: 19px;
    }

    .setForAnswer label {
        color: #ffffff !important;
    }

    .about_company_style
    {
        color: #ffffff !important;
        font-size: 20px;

    }

    .about_company_style::before {
        right: -2.5rem;
        display: block;
        width: 25px;
        height: 25px;
    }

    .about_company_style::after {
        right: -40px;
        width: 25px;
        height: 25px;
    }

    .yes_or_no
    {
        margin: 0 25px;
    }
    .test1n {
        margin-bottom: 6px;
        font-size: 20px;
        color: #28a745;
    }
    #qrcode img
    {
        display: initial !important;
    }

    .logo_on_qr
    {
        text-align: center;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .logo_on_qr .img_logo_qr
    {
        position: absolute;
        background: white;
        padding-right: 5px;
        width: 75px;
    }
    .phone_number_found {
        background: #FFC107;
        font-size: 14px;
        margin-bottom: 2px;
        padding: 3px 7px;
    }


    .video_view
    {
        width: 100%;
        z-index: 150000;
    }




    .video_view::-webkit-media-controls {
        display:none !important;
    }

    .noteAfter_video
    {
        display: none;
    }

    .question_after_video
    {
        display: none;
    }

    .carousel-item {

        transition: -webkit-transform .3s ease-in-out;
        transition: transform .3s ease-in-out;
        transition: transform .3s ease-in-out, -webkit-transform .3s ease-in-out;
    }

</style>

<script>

    function set_back_layer() {

        $('.xnext').addClass('carousel-item-next carousel-item-left')
        $('.xback').addClass('active carousel-item-left')
        setTimeout(function () {
            $('.xnext').removeClass('carousel-item-left')
            $('.xnext').removeClass('active')

        },40)

        setTimeout(function () {
            $('.xback').removeClass(' carousel-item-left')

        },50)

        setTimeout(function () {
            $('.xnext').removeClass('carousel-item-next')

        },500)


    }

</script>


<script>


    function showResult(phone)
    {

        $.get( "<?php  echo url  ?>/customers/chphone/"+phone, function( data ) {
            if (data==='found')
            {
                $('.chphone').html('<div class="phone_number_found">رقم الهاتف مسجل مسبقا يرجى الرجوع الى الفقرة السابقة .</div>')
                $('#phone').addClass('xphonea')
            }else {
                $('.chphone').empty();
                $('#phone').removeClass('xphonea')
            }
        });

    }

    $(document).ready(function(){
        $('.video_view').on('ended',function(){

            closeFullscreen();
            setTimeout(function () {
                $('.lsat_layer').removeAttr("disabled");
                $('.question_after_video input').attr('required','required');
                $('.video_view').hide('fast');
                $('.question_after_video').show('fast');
                $('.action4').show('fast');
            },500);

        });
    });


    $('input[name="about_company"]').change(function() {
        val= $('input[name="about_company"]:checked').val();
        if (val==='1')
        {

            $('.next_choose').show();
            $('.open_video_fast').hide();

        }else
        {

            $('.next_choose').hide();
            $('.open_video_fast').show();

        }

        $('.ff3').removeAttr('disabled')

    });



    function gotoVideo()
    {



        $('.ONNo').removeClass('active')
        $('.open_video').addClass('active')

        openFullscreen();
        $('.video_view').show();
        $('.video_view').get(0).play()

    }



    $('input[name="after_video"]').change(function() {
        val= $('input[name="after_video"]:checked').val();
        if (val==='1')
        {
            $('.noteAfter_video textarea').removeAttr('required');
            $('.noteAfter_video').hide('fast');
        }else
        {

            $('.noteAfter_video textarea').attr('required','required');
            $('.noteAfter_video').show('fast');
        }

    });


    $('input[name="forAnswerThat"]').change(function() {
        val2= $('input[name="forAnswerThat"]:checked').val();
        if (val2==='1' ||  val2==='2' )
        {
            $('.choose_1_2').show();
            $('.choose3').hide();

        }else
        {
            $('.choose3').show();
            $('.choose_1_2').hide();
            $('.noteAfter_video').hide('fast');
            $(".fakeRadio").prop( "checked", false );
            $('.fakeRadio').removeAttr('required')
            $('#write_note').removeAttr('required')
        }

        $('.ff4').removeAttr('disabled')

    });

    function step2back() {

    setTimeout(function () {

        val= $('input[name="about_company"]:checked').val();
        if ( val==='2' )
        {
            $('.goback').click();
        }
    },500)


}




    function openFullscreen() {
        var elem = document.getElementById("myvideo_play");
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) { /* Firefox */
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) { /* IE/Edge */
            elem.msRequestFullscreen();
        }
    }

    function closeFullscreen() {
        var elem = document.getElementById("myvideo_play");
        if (elem.exitFullscreen) {
            elem.exitFullscreen();
        } else if (elem.mozCancelFullScreen) {
            elem.mozCancelFullScreen();
        } else if (elem.webkitExitFullscreen) {
            elem.webkitExitFullscreen();
        } else if (elem.msExitFullscreen) {
            elem.msExitFullscreen();
        }
    }




    $('#exampleModal_register_new').modal({
        backdrop: 'static',
        keyboard: false
    });



    $("#idFormReg").submit(function(e) {

        e.preventDefault();
        var form = $(this);
        var url = form.attr('action');
        var formData = new FormData(this);
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            success: function (result) {
                var response = JSON.parse(result);
                if (response.error) {
                    for (var prop in response.error) {
                        $('*[name="' + prop + '"]').addClass('is-invalid');
                    }

                 alert('يرجى مراجة المعلومات المدخلة.')

                } else if (response.done) {

                    infoUrl="<?php  echo url ?>/customers/qr/"+response.done['done'];
                    var qrcode = new QRCode("qrcode");
                    qrcode.makeCode(infoUrl);

                    $('span.name_customer').text($('#first_name').val());
                    $('#exampleModal_hello_customer').modal({
                        backdrop: 'static',
                        keyboard: false
                    });

                } else {
                  alert('فشل التسجيل يرجى اعادة التسجيل ')
                    window.location="<?php echo url ?>"
                }
            },
            cache: false,
            contentType: false,
            processData: false
        })

    });


    function enterSite()
    {

        var timeleft = 100;
        var downloadTimer = setInterval(function(){
            if(timeleft <= 0){
                clearInterval(downloadTimer);
            }
            $('.progress_inter').css('width',100 - timeleft +'%');
            timeleft -= 1;
            if (timeleft===0)
            {
                window.location="<?php echo url ?>"
            }
        }, 25);

    }


    $("#search_phone").submit(function(e) {
        e.preventDefault();
        var form = $(this);
        var url = form.attr('action');
        var formData = new FormData(this);
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            success: function (result) {
                var response = JSON.parse(result);

                if (response.error) {
                    $('.after_phone').click();

                } else if (response.done) {

                    infoUrl="<?php  echo url ?>/customers/qr/"+response.done['done'];
                    var qrcode = new QRCode("qrcode");
                    qrcode.makeCode(infoUrl);

                    $('span.name_customer').text(response.done['first_name']);
                    $('#exampleModal_hello_customer').modal({
                        backdrop: 'static',
                        keyboard: false
                    });

                } else {
                    $('.after_phone').click();
                }
            },
            cache: false,
            contentType: false,
            processData: false
        })

    });


    function checkfield1() {


        if ($('#first_name').val() && $('#title').val())
        {
            $('.ff1').removeAttr("disabled");
        }else
        {
            $('.ff1').attr("disabled","disabled");
        }


    }


    function checkfield2() {

       var conceptName = $('#city').find(":selected").val();
        if ($('#phone').val() && $('#address').val() && conceptName)
        {
            $('.ff2').removeAttr("disabled");
        }else
        {
            $('.ff2').attr("disabled","disabled");
        }


    }

    function goPhoneToTextbox(e) {
        $('#phone').val($(e).val())
    }



</script>



<div class="modal fade"  id="exampleModal_hello_customer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div style="width: 100%" class="row justify-content-between align-content-center">
                    <div class="col-auto">
                        <h5 style=" margin-top: 3px;   font-size: 26px;"  class="modal-title" id="exampleModalLabel"> <span>مرحبا</span>  <span class="name_customer"></span> </h5>
                    </div>

                    <div class="col-auto" style="padding: 0">
                        <img style="width: 70px;" src="<?php  echo  $this->static_file_site ?>/image/site/logo_notif.png">
                    </div>
                </div>


            </div>
            <div class="modal-body" id="message_out">
                <div class="test1n">  شكرا لستخدامك شاشة الحقيقة يرجى الاحتفاظ برمز QR الخاص بك ذلك عن طريق اخذ لقطة شاشة واضحة له.    </div>
                <div class="logo_on_qr">
                    <div id="qrcode"></div>
                    <img class="img_logo_qr" src="<?php  echo  $this->static_file_site ?>/image/site/logo_notif.png">
                </div>
                <br>
                <div class="progress" style="height: 2px;">
                    <div  class="progress-bar progress_inter" role="progressbar" style="width: 0;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div  class="col-12" style="margin-bottom: 5px;text-align: center"> هل تريد الدخول؟ </div>
                <div class="col-auto">
                    <button class="btn btn-primary" onclick="enterSite()">نعم</button>
                </div>
                <div class="col-auto">
                    <button class="btn btn-danger" onclick="window.location='<?php  echo url ?>/register/logout'">لا</button>
                </div>
            </div>
            <br>
        </div>
    </div>
</div>





<div class="modal  " id="exampleModal_qr" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> تسجيل الدخول بستخدام رمز QR   </h5>

            </div>
            <div class="modal-body">
                <div class="iconqr" style="margin-bottom: 18px;text-align: center">
                    <img width="100" src="<?php echo $this->static_file_site ?>/image/site/qr.png">
                </div>

                <form id="rprice"  method="post" action="<?php echo url .'/'. $this->folder ?>/rprice">
                    <div class="error_qr"></div>
                    <div class="form-row align-items-center">

                        <div class="col" style="position: relative">
                            <input type="search"    autocomplete="off"   name="qr" class="form-control" id="qrcodeprice" placeholder="اضغط هنا ثم قم بتوجيه رمز QR الخاص بك نحو الكامرة"  required>
                        </div>

                    </div>
                </form>


            </div>
            <div class="modal-footer"></div>
        </div>
    </div>
</div>


<script>


    function select_qr()
    {

        $("#qrcodeprice").val('');
        $(document).ready(function() {
            $("#qrcodeprice").select();
        });

    }


    $("#rprice").submit(function(e) {
        e.preventDefault(); // avoid to execute the actual submit of the form.
        var form = $(this);
        var url = form.attr('action');
        img=$('input[name="color"]:checked').val();
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize()+"&img="+img+"&submit=submit", // serializes the form's elements.
            success: function(data)
            {
                if (data==='rqr')
                {
                    select_qr()
                    $(".error_qr").text('رمز QR الخاص بك غير صحيح!');
                } else if (data==='true')
                {
                    select_qr()
                    $(".error_qr").html("<span style='color: green'>جاري تسجيل الدخول ...</span>");
                    window.location="<?php echo url ?>"
                }else
                {
                    select_qr()
                    $(".error_qr").text('رمز QR الخاص بك غير صحيح!');
                }
            }
        });


    });

</script>
<style>
    button.btn.readQrbtn {
        color: #fff;
        font-size: 54px;
        padding: 0;
        height: 62px;
    }
    .error_qr{
        color: red;
        margin-bottom: 5px;
    }
</style>



</body>
</html>
