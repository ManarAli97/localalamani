<div style="color: red;"> afwefwqef</div>


sddg<?php echo 1 ?>gsgwegr
sddg {$this->c} gsgwegr